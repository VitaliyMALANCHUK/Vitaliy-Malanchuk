$('input, textarea').placeholder();
$('input, textarea').placeholder({ customClass: 'my-placeholder' });